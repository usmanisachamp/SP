lis =[[1, 2, 3, 4, 53, 6, 7, 8], 
	  [9, 2, 3, 4, 22, 3, 4, 3], 
	  [12, 12, 11, 15, 1, 6, 7, 7], 
	  [23, 23, 43, 44, 5, 2, 5, 3], 
	  [23, 22, 45, 52, 1, 6, 5, 6], 
	  [78, 56, 24, 36, 5, 1, 2, 6], 
	  [52, 51, 31, 26, 1, 5, 3, 3], 
	  [65, 73, 33, 27, 8, 6, 9, 7]]
strow00=input("Enter a Number for [0][0]: ")
strow01=input("Enter a Number for [0][1]: ")
strow10=input("Enter a Number for [1][0]: ")
strow11=input("Enter a Number for [1][1]: ")
#stcol=input("Enter a Number for Column:")
m00=int(strow00)
m01=int(strow01)
m10=int(strow10)
m11=int(strow11)

br=0
for i in range(0,7):
	for j in range(0,7):
		if(lis[i][j] == m00 and lis[i+1][j] == m10 and lis[i][j+1] == m01 and lis[i+1][j+1] == m11):
			print "({0},{1})".format(i+1,j+1)
			br=br+1
			
		
if(br is not 1):	
	print "MATRIX DONT FOUND"	
#col=int(stcol)

