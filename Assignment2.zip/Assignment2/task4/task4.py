import os
import psutil
import time

processID=input("ENTER PROCESS ID : ")
for process in psutil.process_iter():
	if(process.pid == processID):
		print "PROCESS ID :{0}".format(process.pid)
		print "PROCESS NAME : {0}".format(process.name)
		print "PEOCESS STATUS : {0}".format(process.status)
		print "PROCESS PARENT ID : {0}".format(process.ppid)
		print "PROCESS CREATION TIME : {0}".format(process.create_time)
		print "PROCESS MEMORY INFO : {0}".format(process.get_memory_info)
		print "FILES OPENED BY PROCESS : {0}".format(process.get_open_files)
		
