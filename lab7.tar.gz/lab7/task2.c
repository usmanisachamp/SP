#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

int main(int args,char *argv[])
{
	int n;
	int fd = open ("/etc/shadow",O_RDONLY);
	int fd1 =open (argv[1],O_CREAT | O_RDWR,0777);
	char buff[255];
	while(1)
	{
		n=read(fd,buff,255);
		if(n<=0)
			break;
		if(args==1)
			write(1,buff,n);
		else
			write(fd1,buff,n);
	}
}