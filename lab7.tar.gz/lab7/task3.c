#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

int main()
{
	int n;
	int fd = open ("data.txt",O_RDONLY);
	int fd1 =open ("data1.txt",O_WRONLY);
	char buff[255];
	while(1)
	{
		n=read(fd,buff,255);
		if(n<=0)
			break;
		write(fd1,buff,n);
	}
}