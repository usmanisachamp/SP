#include<stdio.h>
#include<unistd.h>
#include<fcntl.h>

int main(int args,char *argv[])
{
	int n;
	int fd1=1;
	int fd = open (argv[1],O_RDONLY);
	if (args >1)
	{
		close(1);
		fd1 =open (argv[2],O_CREAT | O_RDWR,0777);
	}
	char buff[255];
	while(1)
	{
		n=read(fd,buff,255);
		if(n<=0)
			break;
		write(fd1,buff,n);
	}
}