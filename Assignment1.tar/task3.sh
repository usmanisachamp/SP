#!/bin/bash

lower_case_conversion()
{
	read -p "Enter a string to be converted into loweer_case : " string
#	echo ${string,,}
	string=${string,,}
	echo $string
}

lower_case_conversion 

