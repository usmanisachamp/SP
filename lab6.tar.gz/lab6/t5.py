str = raw_input("Enter your string  :")
upper_str = str.upper()
print(upper_str)