integral_number = raw_input("Enter Integer : ")
dict = {}
for i in (0, integral_number):
	dict[i] = i*i
