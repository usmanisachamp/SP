list = []
str = raw_input("Please Enter Input : ")
list = str.split(' ')

list.sort()
print(list)