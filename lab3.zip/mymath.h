int isequal(int,int);
int swap(int,int);
