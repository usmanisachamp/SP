#include<stdio.h>
#include<string.h>
#include "mystr.h"
int main()
{
	char arr[] ="aba";
	if (palindrome(arr,3)==1)
	{
		printf("yes it is palindrome");
	}
	else
	{
		printf("no it is not palindrome");
	}

        
	
}
	
	
