#include<stdio.h>
#include<unistd.h>
void main()
{

	uid_t ruid, euid, suid;
	gid_t rgid, egid, sgid;
	getresuid(&ruid, &euid, &suid);
	printf("My real User-ID is: %d\n", (long)ruid);
	printf("My Effective User-ID is: %d\n", (long)euid);
	printf("My Saved Set-User-ID is: %d\n", (long)suid);
	getresgid(&rgid, &egid, &sgid);
	printf("My real Group-ID is: %d\n", (long)rgid);
	printf("My Effective Group-ID is: %d\n", (long)egid);
	printf("My Saved Set-Group-ID is: %d\n", (long)sgid);
}
