#include<stdio.h>
#include<stdlib.h>
void main()
{
	printf("Real ID: %d\n",(long)getuid());
	printf("Effective ID: %d\n",(long)geteuid());
	printf("Real Group ID: %d\n",(long)getgid());
	printf("Effective Group ID: %d\n",(long)getegid());
}
