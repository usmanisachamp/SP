#include<stdio.h>
#include<unistd.h>
void main()
{
	uid_t ruid, euid, suid;
	gid_t rgid, egid, sgid;
	getresuid(&ruid, &euid, &suid);
	printf("My real User-ID is: %d\n", (long)ruid);
	printf("My Effective User-ID is: %d\n", (long)euid);
	printf("My Saved Set-User-ID is: %d\n", (long)suid);
	int rv = setuid(501);
	if(rv != -1)
	{
		getresuid(&ruid, &euid, &suid);
		printf("\n\nAfter setuid(501), Following are the ID's:\n");
		printf("My real User-ID is: %d\n", (long)ruid);
		printf("My Effective User-ID is: %d\n", (long)euid);
		printf("My Saved Set-User-ID is: %d\n", (long)suid);
	}
	else printf("Error in setting ID\n");
}
