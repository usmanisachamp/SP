#!/bin/bash
showTable()
{
	if [ $# = 0 ]
	then

		echo "There is no argument so no table will print"

	elif [ $# -ge 7 ]
	then
		echo "Arguments should not be more than 6"	
	elif [ $1 != 0 -a $# = 1 ]
	then 
		varTable=$1
		for i in `seq 1 10`
		do 
			echo `expr $varTable \* $i`
		done
	elif [ $# = 3 -a $2 = "-s" ]
	then
		varTable=$1
		tableRange=$3
		for i in `seq $tableRange 10`
		do 
			echo `expr $varTable \* $i`
		done	
	elif [ $# = 3 -a $2 = "-e" ]
	then
		varTable=$1
		tableRange=$3
		for i in `seq 1 $tableRange`
		do 
			echo `expr $varTable \* $i`
		done
	elif [ $# = 5 -a $2 = "-s" -a $4 = "-e" ]
	then
		varTable=$1
		tableStart=$3
		tableRange=$5
		for i in `seq $tableStart $tableRange`
		do 
			echo `expr $varTable \* $i`
		done
	elif [ $# = 6 -a $2 = "-s" -a $4 = "-e" -a $6 = "-r" ]
	then
		varTable=$1
		tableStart=$3
		tableRange=$5
		i=$5
		while [ $i -ge $tableStart ]
		do
		{
			echo `expr $varTable \* $i`
			i=$(($i-1))
		}
		done
#		for i in `seq $tableRange $tableStart `
#		do 
#			echo `expr $varTable \* $i`
#		done
#	else 
#		echo "There is no argument so no table will print"
	fi
}

showTable $@
